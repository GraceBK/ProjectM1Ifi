package boukou.grace.projectm1ifi;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PendingIntent;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Objects;

import boukou.grace.projectm1ifi.db.room_db.AppDatabase;
import boukou.grace.projectm1ifi.db.room_db.Msg;
import boukou.grace.projectm1ifi.db.sqlite_db.SmsSQLiteOpenHelper;
import boukou.grace.projectm1ifi.java_files.MySms;
import boukou.grace.projectm1ifi.java_files.cesar.Cesar;

public class DetailActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;

    private BroadcastReceiver sendBroadcastReceiver;
    private BroadcastReceiver deliveredBroadcastReceiver;
    String SENT = "SMS_SENT";
    String DELIVERED = "SMS_DELIVERED";

    RecyclerView mySmsRecycler;
    private MsgAdapter adapter;
    private MsgViewModel viewModel;

    List<Msg> msgList;

    private AppDatabase db;

    String name;
    String phone;
    String sms_clair;
    String sms_chiffre;
    String sender = "sender";

    TextView sms;
    TextView current_time;

    int cle;

//    SmsSQLiteOpenHelper sqLiteOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        db = AppDatabase.getDatabase(getApplicationContext());

//        msgList = db.msgDao().getAllMsg();


        name = getIntent().getStringExtra("USERNAME");
        phone = getIntent().getStringExtra("PHONE");

        getSupportActionBar().setTitle(name);
        msgList = db.msgDao().getAllMsgByNumber(phone);

        sms = findViewById(R.id.edit_txt_send);
        //current_time = findViewById(R.id.e);

        // TODO : DB
        //sqLiteOpenHelper = new SmsSQLiteOpenHelper(this);

        //smsList = sqLiteOpenHelper.getSmsByPhoneNumber(phone);

        mySmsRecycler = findViewById(R.id.container_sms);
        mySmsRecycler.setLayoutManager(new LinearLayoutManager(this));

        adapter = new MsgAdapter(msgList);
        mySmsRecycler.smoothScrollToPosition(msgList.size());
        mySmsRecycler.setAdapter(adapter);


        viewModel = ViewModelProviders.of(this).get(MsgViewModel.class);
        viewModel.getMsgList().observe(this, new Observer<List<Msg>>() {
            @Override
            public void onChanged(@Nullable List<Msg> msgs) {
                //adapter.update(msgs);
            }
        });



        /*
          J'enregistre les receivers ici car dans sendSMS y a deux erreur du type:
           * Pour l'accuse d'envoi
                E/ActivityThread: Activity boukou.grace.projectm1ifi.DetailActivity has leaked IntentReceiver boukou.grace.projectm1ifi.DetailActivity$3@892dd21 that was originally registered here. Are you missing a call to unregisterReceiver()?
           * Pour l'accuse de reception
                E/ActivityThread: Activity boukou.grace.projectm1ifi.DetailActivity has leaked IntentReceiver boukou.grace.projectm1ifi.DetailActivity$2@a3f2f88 that was originally registered here. Are you missing a call to unregisterReceiver()?

             Ensuite dans onStop on desinscrit les receivers de l'activite

          mais pas de quoi faire planter l'APP.

          SOLUTION SUR : https://stackoverflow.com/questions/9078390/intentrecieverleakedexception-are-you-missing-a-call-to-unregisterreceiver
         */
        // Quand le SMS a ete envoye
        sendBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), "SMS envoyé", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        // TODO : action a faire si SMS non livré
                        Toast.makeText(getBaseContext(), "SMS non livré", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        // TODO : action a faire si Pas de service
                        Toast.makeText(getBaseContext(), "Pas de service", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        // TODO : action a faire si PDU nul
                        Toast.makeText(getBaseContext(), "PDU nul", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        // TODO : action a faire si Radio éteinte
                        Toast.makeText(getBaseContext(), "Radio éteinte", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        };
        // Quand le SMS a ete livre
        deliveredBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), "SMS livré", Toast.LENGTH_SHORT).show();
                        SmsManager smsKEY = SmsManager.getDefault();
                        smsKEY.sendTextMessage(phone, null, "Cesar Password = " + cle, null, null);
                        break;
                    case Activity.RESULT_CANCELED:
                        // TODO : action a faire si SMS non livré
                        Toast.makeText(getBaseContext(), "SMS non livré", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        };
        registerReceiver(sendBroadcastReceiver, new IntentFilter(SENT));
        registerReceiver(deliveredBroadcastReceiver, new IntentFilter(DELIVERED));

        FloatingActionButton fab = findViewById(R.id.fab_send);
        fab.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("StaticFieldLeak")
            @Override
            public void onClick(View view) {
                Log.e("rrrr", sms.getText().toString() + " " + phone);
                if (!sms.getText().toString().isEmpty()) {
                    cle = Cesar.generateKey();
                    // TODO add requestSmsPermission() dans un try
                    sms_clair = sms.getText().toString();
                    sms_chiffre = Cesar.crypter(cle, sms_clair);
                    sendSMS(sms_chiffre);
                    // DONE Action envoye
                    // Deplacer cette fonction
                    //sqLiteOpenHelper.addSMS(new MySms(phone, sms_clair, ""+cle, sender));
                    Msg msg = new Msg();
                    msg.phoneReceiver = phone;
                    msg.phoneSender = sender;
                    msg.sms1 = sms_chiffre;
                    msg.sms2 = sms_clair;
                    msg.key = ""+cle;

                    new AsyncTask<Msg, Void, Void>() {

                        @Override
                        protected Void doInBackground(Msg... msgs) {
                            for (Msg msg1 : msgs) {
                                db.msgDao().insertSms(msg1);
                            }
                            return null;
                        }
                    }.execute(msg);
                    sms.setText("");
                }
            }
        });
    }


    // TODO : faire appel a cette methode
    public void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                // Cela signifie que la permission a deja ete demande et l'utilisateur l'a refuse
                // On peut aussi expliquer a l'utilisateur pourquoi
                // cette permission est necessaire et la redemander
            } else {
                // Sinon demander la permission
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
    }

    protected void sendSMS(String msg) {
        try {
            String SENT = "SMS_SENT";
            String DELIVERED = "SMS_DELIVERED";

            PendingIntent sentPendingIntent = PendingIntent.getBroadcast(this, 0, new Intent(SENT), 0);
            PendingIntent deliveredPendingIntent = PendingIntent.getBroadcast(this, 0, new Intent(DELIVERED), 0);
/*
            // Quand le SMS a ete envoye
            registerReceiver(new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    switch (getResultCode()) {
                        case Activity.RESULT_OK:
                            Toast.makeText(getBaseContext(), "SMS envoye", Toast.LENGTH_SHORT).show();
                            break;
                    }
                }
            }, new IntentFilter(SENT));
            // Quand le SMS a ete livre
            registerReceiver(new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    switch (getResultCode()) {
                        case Activity.RESULT_OK:
                            Toast.makeText(getBaseContext(), "SMS livre", Toast.LENGTH_SHORT).show();
                            SmsManager smsKEY = SmsManager.getDefault();
                            smsKEY.sendTextMessage(phone, null, "crypté avec Cesar Mot de passe = 2", null, null);
                            break;
                    }
                }
            }, new IntentFilter(DELIVERED));
*/
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, "MY_APP " + Cesar.crypter(cle, msg), sentPendingIntent, deliveredPendingIntent);
            // Toast.makeText(getApplicationContext(), "SMS envoye.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            // Toast.makeText(getApplicationContext(), "Envoie faild. Verifier les permissions.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // La permission est garantie
                } else {
                    // La permission est refusee
                }
                return;
            }
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    @Override
    protected void onStop() {
        if (sendBroadcastReceiver != null || deliveredBroadcastReceiver != null) {
            unregisterReceiver(sendBroadcastReceiver);
            unregisterReceiver(deliveredBroadcastReceiver);
        }
        sendBroadcastReceiver = null;
        deliveredBroadcastReceiver = null;
        //unregisterReceiver(sendBroadcastReceiver);
        //unregisterReceiver(deliveredBroadcastReceiver);
        super.onStop();
    }

}
