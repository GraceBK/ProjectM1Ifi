package boukou.grace.projectm1ifi.db.sqlite_db;

import android.provider.BaseColumns;

/**
 * boukou.grace.projectm1ifi.db
 * Created by grace on 17/04/2018.
 */
public class MySmsContract {

    public static abstract class MySmsEntry implements BaseColumns {

    }
}
